import java.sql.*;
import java.util.*;
/**
   *Amina Mahmood
   *ISTE 330.01-02
   *Mr. Floeser
   *Database Connectivity and Access
   *Pratice Exercise 9
*/
// Create a class business layer
public class BLUser extends DLUser
{
   // Create a method with two parameters
   public BLUser(String username, String password)
   {
      super(username, password);
   } 
}